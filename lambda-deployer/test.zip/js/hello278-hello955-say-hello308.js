module.exports.hello278 = (data)=>{
            return "currenty you won't get right answer as open ai api key's free trial is finished is not working"
        }

module.exports.hello955 = (data)=>{
            return "currenty you won't get right answer as open ai api key's free trial is finished is not working"
        }

module.exports.say_hello308 = (name)=>{
            return "hello "+name
        }